<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\viaje;
use Faker\Generator as Faker;

$factory->define(viaje::class, function (Faker $faker) {
    return [
        //
    ];
});
