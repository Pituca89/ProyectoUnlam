<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\sector;
use Faker\Generator as Faker;

$factory->define(sector::class, function (Faker $faker) {
    return [
        //
    ];
});
