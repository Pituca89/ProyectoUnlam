<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\usuario;
use Faker\Generator as Faker;

$factory->define(usuario::class, function (Faker $faker) {
    return [
        //
    ];
});
