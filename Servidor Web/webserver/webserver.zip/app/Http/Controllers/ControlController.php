<?php

namespace App\Http\Controllers;

use App\control;
use Illuminate\Http\Request;

class ControlController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\control  $control
     * @return \Illuminate\Http\Response
     */
    public function show(control $control)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\control  $control
     * @return \Illuminate\Http\Response
     */
    public function edit(control $control)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\control  $control
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, control $control)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\control  $control
     * @return \Illuminate\Http\Response
     */
    public function destroy(control $control)
    {
        //
    }
}
