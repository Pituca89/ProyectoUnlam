<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\plataforma;
use Faker\Generator as Faker;

$factory->define(plataforma::class, function (Faker $faker) {
    return [
        //
    ];
});
