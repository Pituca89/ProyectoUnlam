<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\notificacion;
use Faker\Generator as Faker;

$factory->define(notificacion::class, function (Faker $faker) {
    return [
        //
    ];
});
