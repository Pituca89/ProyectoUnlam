<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ruta;
use Faker\Generator as Faker;

$factory->define(ruta::class, function (Faker $faker) {
    return [
        //
    ];
});
