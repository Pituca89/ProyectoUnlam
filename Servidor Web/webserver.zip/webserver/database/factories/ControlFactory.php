<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\control;
use Faker\Generator as Faker;

$factory->define(control::class, function (Faker $faker) {
    return [
        //
    ];
});
