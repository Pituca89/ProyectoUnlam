<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class control extends Model
{
    //
}
