<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class plataforma extends Model
{
    //
}
